﻿using System;
using System.Globalization;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Witaj w programie obliczania rabatu na przeloty!");

        DateTime birthDate = GetValidDate("Podaj swoją datę urodzenia w formacie RRRR-MM-DD: ");
        DateTime flightDate = GetValidDate("Podaj datę lotu w formacie RRRR-MM-DD: ");
        bool isDomestic = GetYesOrNo("Czy lot jest krajowy (T/N)? ");
        bool isRegularCustomer = GetYesOrNo("Czy jesteś stałym klientem (T/N)? ");

        DisplayCollectedData(birthDate, flightDate, isDomestic, isRegularCustomer);

        int discount = CalculateDiscount(birthDate, flightDate, isDomestic, isRegularCustomer);

        Console.WriteLine($"Przysługuje Ci rabat w wysokości: {discount}%");
        Console.WriteLine($"Data wygenerowania raportu: {DateTime.Now}");
    }

    static DateTime GetValidDate(string message)
    {
        DateTime date;
        Console.Write(message);
        while (!DateTime.TryParseExact(Console.ReadLine(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
        {
            Console.WriteLine("Niepoprawny format daty, spróbuj ponownie.");
            Console.Write(message);
        }
        return date;
    }

    static bool GetYesOrNo(string message)
    {
        Console.Write(message);
        string response;
        while (true)
        {
            response = Console.ReadLine().Trim().ToUpper();
            if (response == "T") return true;
            if (response == "N") return false;

            Console.WriteLine("Niepoprawna odpowiedź, wpisz T (tak) lub N (nie).");
            Console.Write(message);
        }
    }

    static void DisplayCollectedData(DateTime birthDate, DateTime flightDate, bool isDomestic, bool isRegularCustomer)
    {
        Console.WriteLine("\n=== Do obliczeń przyjęto:");
        Console.WriteLine($" * Data urodzenia: {birthDate:dd.MM.yyyy}");
        Console.WriteLine($" * Data lotu: {flightDate:dddd, d MMMM yyyy}. Lot w sezonie: {(IsSeason(flightDate) ? "Tak" : "Nie")}");
        Console.WriteLine($" * Lot {(isDomestic ? "krajowy" : "międzynarodowy")}");
        Console.WriteLine($" * Stały klient: {(isRegularCustomer ? "Tak" : "Nie")}\n");
    }
    static bool IsSeason(DateTime date)
    {
        int year = date.Year;
        var summerStart = new DateTime(year, 7, 1);
        var summerEnd = new DateTime(year, 8, 31);
        var winterStart = new DateTime(year, 12, 20);
        var winterEnd = new DateTime(year + 1, 1, 10);
        var springStart = new DateTime(year, 3, 20);
        var springEnd = new DateTime(year, 4, 10);

        return (date >= summerStart && date <= summerEnd) ||
               (date >= winterStart && date <= winterEnd) ||
               (date >= springStart && date <= springEnd);
    }

    static int CalculateDiscount(DateTime birthDate, DateTime flightDate, bool isDomestic, bool isRegularCustomer)
    {
        int discount = 0;
        TimeSpan age = flightDate - birthDate;

        // Rabaty dla niemowląt i młodzieży
        if (age.TotalDays < 730) // Mniej niż 2 lata
        {
            discount += isDomestic ? 80 : 70;
        }
        else if (age.TotalDays < 5840) // Od 2 do 16 lat
        {
            discount += 10;
        }

        // Rabat dla stałych klientów
        if (isRegularCustomer && birthDate.AddYears(18) <= flightDate)
        {
            discount += 15;
        }

        // Rabaty dotyczące daty lotu
        if (!isDomestic && !IsSeason(flightDate))
        {
            discount += 15;
        }

        // Ograniczenia maksymalnego rabatu
        if (age.TotalDays < 730) // Niemowlęta
        {
            discount = Math.Min(discount, 80);
        }
        else
        {
            discount = Math.Min(discount, 30);
        }

        return discount;
    }
}
